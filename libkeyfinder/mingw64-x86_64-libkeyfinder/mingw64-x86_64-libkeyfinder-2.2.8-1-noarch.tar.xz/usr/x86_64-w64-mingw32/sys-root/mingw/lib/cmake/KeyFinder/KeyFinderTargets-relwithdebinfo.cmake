#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KeyFinder::keyfinder" for configuration "RelWithDebInfo"
set_property(TARGET KeyFinder::keyfinder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(KeyFinder::keyfinder PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libkeyfinder.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/libkeyfinder.dll"
  )

list(APPEND _cmake_import_check_targets KeyFinder::keyfinder )
list(APPEND _cmake_import_check_files_for_KeyFinder::keyfinder "${_IMPORT_PREFIX}/lib/libkeyfinder.dll.a" "${_IMPORT_PREFIX}/bin/libkeyfinder.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
