#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "plutosvg::plutosvg" for configuration "RelWithDebInfo"
set_property(TARGET plutosvg::plutosvg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(plutosvg::plutosvg PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libplutosvg.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/libplutosvg.dll"
  )

list(APPEND _cmake_import_check_targets plutosvg::plutosvg )
list(APPEND _cmake_import_check_files_for_plutosvg::plutosvg "${_IMPORT_PREFIX}/lib/libplutosvg.dll.a" "${_IMPORT_PREFIX}/bin/libplutosvg.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
