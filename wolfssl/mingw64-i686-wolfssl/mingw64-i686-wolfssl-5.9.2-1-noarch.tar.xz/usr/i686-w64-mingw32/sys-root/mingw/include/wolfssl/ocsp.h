/* ocsp.h
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * This file is part of wolfSSL.
 *
 * wolfSSL is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * wolfSSL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335, USA
 */



/* wolfSSL OCSP API */

#ifndef WOLFSSL_OCSP_H
#define WOLFSSL_OCSP_H

#ifdef HAVE_OCSP

#include <wolfssl/ssl.h>
#include <wolfssl/wolfcrypt/asn.h>

#ifdef __cplusplus
    extern "C" {
#endif

typedef struct WOLFSSL_OCSP WOLFSSL_OCSP;

#if defined(OPENSSL_ALL) || defined(OPENSSL_EXTRA) || defined(WOLFSSL_NGINX) ||\
    defined(WOLFSSL_HAPROXY) || defined(HAVE_LIGHTY)
typedef struct OcspResponse WOLFSSL_OCSP_BASICRESP;

typedef struct OcspEntry WOLFSSL_OCSP_CERTID;

typedef struct OcspEntry WOLFSSL_OCSP_SINGLERESP;

typedef struct OcspRequest WOLFSSL_OCSP_ONEREQ;

typedef struct OcspRequest WOLFSSL_OCSP_REQUEST;

typedef struct {
    WOLFSSL_BIO *bio;
    WOLFSSL_BIO *reqResp; /* First used for request then for response */
    byte* buf;
    int bufLen;
    int state;
    int ioState;
    int sent;
} WOLFSSL_OCSP_REQ_CTX;
#endif

WOLFSSL_LOCAL int  InitOCSP(WOLFSSL_OCSP* ocsp, WOLFSSL_CERT_MANAGER* cm);
WOLFSSL_LOCAL void FreeOCSP(WOLFSSL_OCSP* ocsp, int dynamic);

WOLFSSL_LOCAL int  CheckCertOCSP(WOLFSSL_OCSP* ocsp, DecodedCert* cert);
WOLFSSL_LOCAL int  CheckCertOCSP_ex(WOLFSSL_OCSP* ocsp, DecodedCert* cert,
                                    WOLFSSL* ssl);
WOLFSSL_LOCAL int  CheckOcspRequest(WOLFSSL_OCSP* ocsp,
                 OcspRequest* ocspRequest, WOLFSSL_BUFFER_INFO* responseBuffer,
                 void* heap);
WOLFSSL_LOCAL int CheckOcspResponse(WOLFSSL_OCSP *ocsp, byte *response, int responseSz,
                                    WOLFSSL_BUFFER_INFO *responseBuffer, CertStatus *status,
                                    OcspEntry *entry, OcspRequest *ocspRequest,
                                    void* heap);

WOLFSSL_LOCAL int CheckOcspResponder(OcspResponse *bs, byte* subjectNameHash,
        byte* subjectKeyHash, byte extExtKeyUsage, byte* issuerNameHash,
        byte* issuerKeyHash);

/* Allocates and initializes a WOLFSSL_OCSP object */
WOLFSSL_API WOLFSSL_OCSP* wc_NewOCSP(WOLFSSL_CERT_MANAGER* cm);
/* Frees a WOLFSSL_OCSP object allocated by wc_NewOCSP */
WOLFSSL_API void wc_FreeOCSP(WOLFSSL_OCSP* ocsp);
WOLFSSL_API int wc_CheckCertOcspResponse(WOLFSSL_OCSP *ocsp, DecodedCert *cert,
        byte *response, int responseSz, void* heap);

WOLFSSL_API OcspRequest* wc_OcspRequest_new(void* heap);
WOLFSSL_API void wc_OcspRequest_free(OcspRequest* request);

WOLFSSL_API int wc_InitOcspRequest(OcspRequest* req, DecodedCert* cert,
                                    byte useNonce, void* heap);
WOLFSSL_API int wc_EncodeOcspRequest(OcspRequest* req, byte* output,
                                      word32 size);

WOLFSSL_API OcspResponse* wc_OcspResponse_new(void* heap);
WOLFSSL_API void wc_OcspResponse_free(OcspResponse* response);

#ifdef OPENSSL_EXTRA
WOLFSSL_API int wolfSSL_OCSP_resp_find_status(WOLFSSL_OCSP_BASICRESP *bs,
                                              WOLFSSL_OCSP_CERTID *id, int *status, int *reason,
                                              WOLFSSL_ASN1_TIME **revtime, WOLFSSL_ASN1_TIME **thisupd,
                                              WOLFSSL_ASN1_TIME **nextupd);
WOLFSSL_API const char *wolfSSL_OCSP_cert_status_str(long s);
WOLFSSL_API int wolfSSL_OCSP_check_validity(WOLFSSL_ASN1_TIME* thisupd,
    WOLFSSL_ASN1_TIME* nextupd, long sec, long maxsec);

WOLFSSL_API void wolfSSL_OCSP_CERTID_free(WOLFSSL_OCSP_CERTID* certId);
WOLFSSL_API WOLFSSL_OCSP_CERTID* wolfSSL_OCSP_cert_to_id(
    const WOLFSSL_EVP_MD *dgst, const WOLFSSL_X509 *subject,
    const WOLFSSL_X509 *issuer);

WOLFSSL_API void wolfSSL_OCSP_BASICRESP_free(WOLFSSL_OCSP_BASICRESP* basicResponse);
WOLFSSL_API int wolfSSL_OCSP_basic_verify(WOLFSSL_OCSP_BASICRESP *bs,
    WOLF_STACK_OF(WOLFSSL_X509) *certs, WOLFSSL_X509_STORE *st, unsigned long flags);

WOLFSSL_API void wolfSSL_OCSP_RESPONSE_free(OcspResponse* response);
#ifndef NO_BIO
WOLFSSL_API OcspResponse* wolfSSL_d2i_OCSP_RESPONSE_bio(WOLFSSL_BIO* bio,
    OcspResponse** response);
#endif
WOLFSSL_API OcspResponse* wolfSSL_d2i_OCSP_RESPONSE(OcspResponse** response,
    const unsigned char** data, int len);
WOLFSSL_API int wolfSSL_i2d_OCSP_RESPONSE(OcspResponse* response,
    unsigned char** data);
WOLFSSL_API int wolfSSL_OCSP_response_status(OcspResponse *response);
WOLFSSL_API const char *wolfSSL_OCSP_response_status_str(long s);
WOLFSSL_API WOLFSSL_OCSP_BASICRESP* wolfSSL_OCSP_response_get1_basic(
    OcspResponse* response);

WOLFSSL_API OcspRequest* wolfSSL_OCSP_REQUEST_new(void);
WOLFSSL_API void wolfSSL_OCSP_REQUEST_free(OcspRequest* request);
WOLFSSL_API int wolfSSL_i2d_OCSP_REQUEST(OcspRequest* request,
    unsigned char** data);
WOLFSSL_API WOLFSSL_OCSP_ONEREQ* wolfSSL_OCSP_request_add0_id(OcspRequest *req,
    WOLFSSL_OCSP_CERTID *cid);
WOLFSSL_API WOLFSSL_OCSP_CERTID* wolfSSL_OCSP_CERTID_dup(
    WOLFSSL_OCSP_CERTID* id);
#ifndef NO_BIO
WOLFSSL_API int wolfSSL_i2d_OCSP_REQUEST_bio(WOLFSSL_BIO* out,
    WOLFSSL_OCSP_REQUEST *req);
#endif

WOLFSSL_API int wolfSSL_i2d_OCSP_CERTID(WOLFSSL_OCSP_CERTID* id,
                                        unsigned char** data);
WOLFSSL_API
WOLFSSL_OCSP_CERTID* wolfSSL_d2i_OCSP_CERTID(WOLFSSL_OCSP_CERTID** cidOut,
                                             const unsigned char** derIn,
                                             int length);
WOLFSSL_API const WOLFSSL_OCSP_CERTID* wolfSSL_OCSP_SINGLERESP_get0_id(
    const WOLFSSL_OCSP_SINGLERESP *single);
WOLFSSL_API int wolfSSL_OCSP_id_cmp(WOLFSSL_OCSP_CERTID *a, WOLFSSL_OCSP_CERTID *b);
WOLFSSL_API int wolfSSL_OCSP_single_get0_status(WOLFSSL_OCSP_SINGLERESP *single,
                                                int *reason,
                                                WOLFSSL_ASN1_TIME **revtime,
                                                WOLFSSL_ASN1_TIME **thisupd,
                                                WOLFSSL_ASN1_TIME **nextupd);
WOLFSSL_API int wolfSSL_OCSP_resp_count(WOLFSSL_OCSP_BASICRESP *bs);
WOLFSSL_API WOLFSSL_OCSP_SINGLERESP* wolfSSL_OCSP_resp_get0(
    WOLFSSL_OCSP_BASICRESP *bs, int idx);

WOLFSSL_API WOLFSSL_OCSP_REQ_CTX* wolfSSL_OCSP_REQ_CTX_new(WOLFSSL_BIO *bio,
        int maxline);
WOLFSSL_API void wolfSSL_OCSP_REQ_CTX_free(WOLFSSL_OCSP_REQ_CTX *ctx);
WOLFSSL_API WOLFSSL_OCSP_REQ_CTX *wolfSSL_OCSP_sendreq_new(WOLFSSL_BIO *bio,
        const char *path, OcspRequest *req, int maxline);
WOLFSSL_API int wolfSSL_OCSP_REQ_CTX_set1_req(WOLFSSL_OCSP_REQ_CTX *ctx,
        OcspRequest *req);
WOLFSSL_API int wolfSSL_OCSP_REQ_CTX_add1_header(WOLFSSL_OCSP_REQ_CTX *ctx,
                             const char *name, const char *value);
WOLFSSL_API int wolfSSL_OCSP_REQ_CTX_http(WOLFSSL_OCSP_REQ_CTX *ctx,
        const char *op, const char *path);
WOLFSSL_API int wolfSSL_OCSP_REQ_CTX_nbio(WOLFSSL_OCSP_REQ_CTX *ctx);
WOLFSSL_API int wolfSSL_OCSP_sendreq_nbio(OcspResponse **presp,
        WOLFSSL_OCSP_REQ_CTX *rctx);

WOLFSSL_API int wolfSSL_OCSP_REQUEST_add_ext(OcspRequest* req,
        WOLFSSL_X509_EXTENSION* ext, int idx);
WOLFSSL_API OcspResponse* wolfSSL_OCSP_response_create(int status,
    WOLFSSL_OCSP_BASICRESP* bs);
WOLFSSL_API const char* wolfSSL_OCSP_crl_reason_str(long s);

WOLFSSL_API int wolfSSL_OCSP_id_get0_info(WOLFSSL_ASN1_STRING **name,
  WOLFSSL_ASN1_OBJECT **pmd, WOLFSSL_ASN1_STRING **keyHash,
  WOLFSSL_ASN1_INTEGER **serial, WOLFSSL_OCSP_CERTID *cid);

WOLFSSL_API int wolfSSL_OCSP_request_add1_nonce(OcspRequest* req,
        unsigned char* val, int sz);
WOLFSSL_API int wolfSSL_OCSP_check_nonce(OcspRequest* req,
        WOLFSSL_OCSP_BASICRESP* bs);
#endif /* OPENSSL_EXTRA */

#ifdef HAVE_OCSP_RESPONDER
/* OCSP Responder API */
WOLFSSL_API OcspResponder* wc_OcspResponder_new(void* heap, int sendCerts);
WOLFSSL_API void wc_OcspResponder_free(OcspResponder* responder);

/* Add a cert that this responder can respond for (DER format only) */
WOLFSSL_API int wc_OcspResponder_AddSigner(OcspResponder* responder,
    const byte* signerDer, word32 signerDerSz,
    const byte* keyDer, word32 keyDerSz,
    const byte* issuerCertDer, word32 issuerCertDerSz);

/* Add a certificate status for a specific CA */
WOLFSSL_API int wc_OcspResponder_SetCertStatus(OcspResponder* responder,
    const char* caSubject, word32 caSubjectSz,
    const byte* serial, word32 serialSz, enum Ocsp_Cert_Status status,
    time_t revocationTime, enum WC_CRL_Reason revocationReason,
    word32 validityPeriod);

/* Generate OCSP response for a request */
WOLFSSL_API int wc_OcspResponder_WriteResponse(OcspResponder* responder,
    const byte* request, word32 requestSz,
    byte* response, word32* responseSz);
WOLFSSL_API int wc_OcspResponder_WriteErrorResponse(
    enum Ocsp_Response_Status status,
    byte* response, word32* responseSz);
#endif /* HAVE_OCSP_RESPONDER */


#ifdef __cplusplus
    }  /* extern "C" */
#endif


#endif /* HAVE_OCSP */
#endif /* WOLFSSL_OCSP_H */


