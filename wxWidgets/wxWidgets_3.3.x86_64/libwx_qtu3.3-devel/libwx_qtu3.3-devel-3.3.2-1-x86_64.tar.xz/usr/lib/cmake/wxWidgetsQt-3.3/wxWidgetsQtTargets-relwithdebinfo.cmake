#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wx::wxbase" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxbase APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxbase PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_baseu-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_baseu-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxbase )
list(APPEND _cmake_import_check_files_for_wx::wxbase "${_IMPORT_PREFIX}/lib/libwx_baseu-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_baseu-3.3-2.dll" )

# Import target "wx::wxnet" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxnet APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxnet PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_baseu_net-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_baseu_net-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxnet )
list(APPEND _cmake_import_check_files_for_wx::wxnet "${_IMPORT_PREFIX}/lib/libwx_baseu_net-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_baseu_net-3.3-2.dll" )

# Import target "wx::wxcore" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxcore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxcore PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_core-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_core-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxcore )
list(APPEND _cmake_import_check_files_for_wx::wxcore "${_IMPORT_PREFIX}/lib/libwx_qtu_core-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_core-3.3-2.dll" )

# Import target "wx::wxadv" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxadv APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxadv PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_adv-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_adv-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxadv )
list(APPEND _cmake_import_check_files_for_wx::wxadv "${_IMPORT_PREFIX}/lib/libwx_qtu_adv-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_adv-3.3-2.dll" )

# Import target "wx::wxaui" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxaui APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxaui PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_aui-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_aui-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxaui )
list(APPEND _cmake_import_check_files_for_wx::wxaui "${_IMPORT_PREFIX}/lib/libwx_qtu_aui-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_aui-3.3-2.dll" )

# Import target "wx::wxhtml" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxhtml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxhtml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_html-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_html-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxhtml )
list(APPEND _cmake_import_check_files_for_wx::wxhtml "${_IMPORT_PREFIX}/lib/libwx_qtu_html-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_html-3.3-2.dll" )

# Import target "wx::wxpropgrid" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxpropgrid APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxpropgrid PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_propgrid-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_propgrid-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxpropgrid )
list(APPEND _cmake_import_check_files_for_wx::wxpropgrid "${_IMPORT_PREFIX}/lib/libwx_qtu_propgrid-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_propgrid-3.3-2.dll" )

# Import target "wx::wxribbon" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxribbon APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxribbon PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_ribbon-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_ribbon-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxribbon )
list(APPEND _cmake_import_check_files_for_wx::wxribbon "${_IMPORT_PREFIX}/lib/libwx_qtu_ribbon-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_ribbon-3.3-2.dll" )

# Import target "wx::wxrichtext" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxrichtext APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxrichtext PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_richtext-3.3.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "wx::wxhtml;wx::wxxml"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_richtext-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxrichtext )
list(APPEND _cmake_import_check_files_for_wx::wxrichtext "${_IMPORT_PREFIX}/lib/libwx_qtu_richtext-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_richtext-3.3-2.dll" )

# Import target "wx::wxstc" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxstc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxstc PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_stc-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_stc-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxstc )
list(APPEND _cmake_import_check_files_for_wx::wxstc "${_IMPORT_PREFIX}/lib/libwx_qtu_stc-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_stc-3.3-2.dll" )

# Import target "wx::wxxrc" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxxrc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxxrc PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_xrc-3.3.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "wx::wxhtml;wx::wxxml"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_xrc-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxxrc )
list(APPEND _cmake_import_check_files_for_wx::wxxrc "${_IMPORT_PREFIX}/lib/libwx_qtu_xrc-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_xrc-3.3-2.dll" )

# Import target "wx::wxmedia" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxmedia APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxmedia PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_media-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_media-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxmedia )
list(APPEND _cmake_import_check_files_for_wx::wxmedia "${_IMPORT_PREFIX}/lib/libwx_qtu_media-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_media-3.3-2.dll" )

# Import target "wx::wxgl" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxgl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxgl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_gl-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_gl-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxgl )
list(APPEND _cmake_import_check_files_for_wx::wxgl "${_IMPORT_PREFIX}/lib/libwx_qtu_gl-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_gl-3.3-2.dll" )

# Import target "wx::wxqa" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxqa APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxqa PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_qtu_qa-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_qtu_qa-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxqa )
list(APPEND _cmake_import_check_files_for_wx::wxqa "${_IMPORT_PREFIX}/lib/libwx_qtu_qa-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_qtu_qa-3.3-2.dll" )

# Import target "wx::wxxml" for configuration "RelWithDebInfo"
set_property(TARGET wx::wxxml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wx::wxxml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwx_baseu_xml-3.3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwx_baseu_xml-3.3-2.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxxml )
list(APPEND _cmake_import_check_files_for_wx::wxxml "${_IMPORT_PREFIX}/lib/libwx_baseu_xml-3.3.dll.a" "${_IMPORT_PREFIX}/bin/cygwx_baseu_xml-3.3-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
