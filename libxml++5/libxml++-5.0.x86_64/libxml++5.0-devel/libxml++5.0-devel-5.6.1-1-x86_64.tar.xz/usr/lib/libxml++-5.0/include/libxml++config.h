#ifndef _LIBXMLPP_CONFIG_H
#define _LIBXMLPP_CONFIG_H

/* Define to omit deprecated API from the library. */
/* #undef LIBXMLXX_DISABLE_DEPRECATED */

/* Defined if the C++ library supports std::exception_ptr. */
#define LIBXMLXX_HAVE_EXCEPTION_PTR 1

/* Major version number of libxml++. */
#define LIBXMLXX_MAJOR_VERSION 5

/* Minor version number of libxml++. */
#define LIBXMLXX_MINOR_VERSION 6

/* Micro version number of libxml++. */
#define LIBXMLXX_MICRO_VERSION 1

#undef LIBXMLXX_STATIC

// Enable DLL-specific stuff only when not building a static library
#if !defined(__CYGWIN__) && (defined(__MINGW32__) || defined(_MSC_VER)) && !defined(LIBXMLXX_STATIC)
# define LIBXMLPP_DLL 1
#endif

#ifdef LIBXMLPP_DLL
  #ifdef LIBXMLPP_BUILD
    #define LIBXMLPP_API __declspec(dllexport)
    #ifdef __GNUC__
      #define LIBXMLPP_VISIBILITY_DEFAULT LIBXMLPP_API __attribute__((visibility("default")))
      #define LIBXMLPP_MEMBER_METHOD
    #endif
  #elif !defined (__GNUC__)
    #define LIBXMLPP_API __declspec(dllimport)
  #else /* don't dllimport classes/methods on GCC/MinGW */
    #define LIBXMLPP_API
  #endif /* LIBXMLPP_BUILD - DLL */
#else
  /* Build a static library or a non-Windows library*/
  #define LIBXMLPP_API
#endif /* GLIBMM_DLL */

#ifndef LIBXMLPP_VISIBILITY_DEFAULT
  #define LIBXMLPP_VISIBILITY_DEFAULT
#endif
#ifndef LIBXMLPP_MEMBER_METHOD
  #define LIBXMLPP_MEMBER_METHOD LIBXMLPP_API
#endif

#endif /* _LIBXMLPP_CONFIG_H */

