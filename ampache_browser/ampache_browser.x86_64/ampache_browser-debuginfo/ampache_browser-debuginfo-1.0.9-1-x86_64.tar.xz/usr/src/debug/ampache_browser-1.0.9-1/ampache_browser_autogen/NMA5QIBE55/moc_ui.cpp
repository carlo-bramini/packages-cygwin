/****************************************************************************
** Meta object code from reading C++ file 'ui.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.18)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../src/ampache_browser-1.0.9/include/internal/ui/ui.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.18. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ui__Ui_t {
    QByteArrayData data[17];
    char stringdata0[336];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ui__Ui_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ui__Ui_t qt_meta_stringdata_ui__Ui = {
    {
QT_MOC_LITERAL(0, 0, 6), // "ui::Ui"
QT_MOC_LITERAL(1, 7, 21), // "onPlayActionTriggered"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 31), // "onCreatePlaylistActionTriggered"
QT_MOC_LITERAL(4, 62, 30), // "onAddToPlaylistActionTriggered"
QT_MOC_LITERAL(5, 93, 11), // "onActivated"
QT_MOC_LITERAL(6, 105, 11), // "QModelIndex"
QT_MOC_LITERAL(7, 117, 39), // "onArtistsSelectionModelSelect..."
QT_MOC_LITERAL(8, 157, 14), // "QItemSelection"
QT_MOC_LITERAL(9, 172, 8), // "selected"
QT_MOC_LITERAL(10, 181, 10), // "deselected"
QT_MOC_LITERAL(11, 192, 38), // "onAlbumsSelectionModelSelecti..."
QT_MOC_LITERAL(12, 231, 38), // "onTracksSelectionModelSelecti..."
QT_MOC_LITERAL(13, 270, 19), // "onSearchTextChanged"
QT_MOC_LITERAL(14, 290, 4), // "text"
QT_MOC_LITERAL(15, 295, 21), // "onSearchReturnPressed"
QT_MOC_LITERAL(16, 317, 18) // "onSettingsAccepted"

    },
    "ui::Ui\0onPlayActionTriggered\0\0"
    "onCreatePlaylistActionTriggered\0"
    "onAddToPlaylistActionTriggered\0"
    "onActivated\0QModelIndex\0"
    "onArtistsSelectionModelSelectionChanged\0"
    "QItemSelection\0selected\0deselected\0"
    "onAlbumsSelectionModelSelectionChanged\0"
    "onTracksSelectionModelSelectionChanged\0"
    "onSearchTextChanged\0text\0onSearchReturnPressed\0"
    "onSettingsAccepted"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ui__Ui[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x08 /* Private */,
       3,    0,   65,    2, 0x08 /* Private */,
       4,    0,   66,    2, 0x08 /* Private */,
       5,    1,   67,    2, 0x08 /* Private */,
       7,    2,   70,    2, 0x08 /* Private */,
      11,    2,   75,    2, 0x08 /* Private */,
      12,    2,   80,    2, 0x08 /* Private */,
      13,    1,   85,    2, 0x08 /* Private */,
      15,    0,   88,    2, 0x08 /* Private */,
      16,    0,   89,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    2,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 8,    9,   10,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 8,    9,   10,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 8,    9,   10,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ui::Ui::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Ui *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onPlayActionTriggered(); break;
        case 1: _t->onCreatePlaylistActionTriggered(); break;
        case 2: _t->onAddToPlaylistActionTriggered(); break;
        case 3: _t->onActivated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 4: _t->onArtistsSelectionModelSelectionChanged((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 5: _t->onAlbumsSelectionModelSelectionChanged((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 6: _t->onTracksSelectionModelSelectionChanged((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 7: _t->onSearchTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->onSearchReturnPressed(); break;
        case 9: _t->onSettingsAccepted(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject ui::Ui::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_ui__Ui.data,
    qt_meta_data_ui__Ui,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ui::Ui::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ui::Ui::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ui__Ui.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ui::Ui::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
