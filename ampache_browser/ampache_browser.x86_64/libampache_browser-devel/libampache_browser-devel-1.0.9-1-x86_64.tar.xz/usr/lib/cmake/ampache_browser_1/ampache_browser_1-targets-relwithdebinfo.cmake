#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ampache_browser" for configuration "RelWithDebInfo"
set_property(TARGET ampache_browser APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ampache_browser PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libampache_browser_1.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Qt5::Core;Qt5::Widgets;Qt5::Concurrent"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygampache_browser_1-0.dll"
  )

list(APPEND _cmake_import_check_targets ampache_browser )
list(APPEND _cmake_import_check_files_for_ampache_browser "${_IMPORT_PREFIX}/lib/libampache_browser_1.dll.a" "${_IMPORT_PREFIX}/bin/cygampache_browser_1-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
