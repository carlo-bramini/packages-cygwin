include("${CMAKE_CURRENT_LIST_DIR}/ampache_browser-targets.cmake")
