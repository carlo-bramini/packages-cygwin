
#ifndef AMPACHE_BROWSER_EXPORT_H
#define AMPACHE_BROWSER_EXPORT_H

#ifdef AMPACHE_BROWSER_STATIC_DEFINE
#  define AMPACHE_BROWSER_EXPORT
#  define AMPACHE_BROWSER_NO_EXPORT
#else
#  ifndef AMPACHE_BROWSER_EXPORT
#    ifdef ampache_browser_EXPORTS
        /* We are building this library */
#      define AMPACHE_BROWSER_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define AMPACHE_BROWSER_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef AMPACHE_BROWSER_NO_EXPORT
#    define AMPACHE_BROWSER_NO_EXPORT 
#  endif
#endif

#ifndef AMPACHE_BROWSER_DEPRECATED
#  define AMPACHE_BROWSER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AMPACHE_BROWSER_DEPRECATED_EXPORT
#  define AMPACHE_BROWSER_DEPRECATED_EXPORT AMPACHE_BROWSER_EXPORT AMPACHE_BROWSER_DEPRECATED
#endif

#ifndef AMPACHE_BROWSER_DEPRECATED_NO_EXPORT
#  define AMPACHE_BROWSER_DEPRECATED_NO_EXPORT AMPACHE_BROWSER_NO_EXPORT AMPACHE_BROWSER_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AMPACHE_BROWSER_NO_DEPRECATED
#    define AMPACHE_BROWSER_NO_DEPRECATED
#  endif
#endif

#endif /* AMPACHE_BROWSER_EXPORT_H */
