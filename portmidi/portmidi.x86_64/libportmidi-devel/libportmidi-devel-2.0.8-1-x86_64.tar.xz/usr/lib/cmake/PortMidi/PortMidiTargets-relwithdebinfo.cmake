#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PortMidi::portmidi" for configuration "RelWithDebInfo"
set_property(TARGET PortMidi::portmidi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(PortMidi::portmidi PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libportmidi.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygportmidi-2.dll"
  )

list(APPEND _cmake_import_check_targets PortMidi::portmidi )
list(APPEND _cmake_import_check_files_for_PortMidi::portmidi "${_IMPORT_PREFIX}/lib/libportmidi.dll.a" "${_IMPORT_PREFIX}/bin/cygportmidi-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
