#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Imath::PyImath" for configuration "RelWithDebInfo"
set_property(TARGET Imath::PyImath APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Imath::PyImath PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libPyImath_Python3_12-3_2.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Python3::Module"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygPyImath_Python3_12-3_2-30.dll"
  )

list(APPEND _cmake_import_check_targets Imath::PyImath )
list(APPEND _cmake_import_check_files_for_Imath::PyImath "${_IMPORT_PREFIX}/lib/libPyImath_Python3_12-3_2.dll.a" "${_IMPORT_PREFIX}/bin/cygPyImath_Python3_12-3_2-30.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
